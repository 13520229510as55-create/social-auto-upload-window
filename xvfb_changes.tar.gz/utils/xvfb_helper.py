"""
Xvfb 虚拟显示服务器辅助模块
用于在无图形界面的服务器上运行非 headless 模式的浏览器
"""
import os
import subprocess
import atexit
import signal
from typing import Optional

_xvfb_process: Optional[subprocess.Popen] = None
_xvfb_display: Optional[str] = None


def start_xvfb(display_num: int = 99, screen: int = 0, width: int = 1920, height: int = 1080, depth: int = 24) -> Optional[str]:
    """
    启动 Xvfb 虚拟显示服务器
    
    Args:
        display_num: 显示编号，默认 99
        screen: 屏幕编号，默认 0
        width: 屏幕宽度，默认 1920
        height: 屏幕高度，默认 1080
        depth: 颜色深度，默认 24
    
    Returns:
        DISPLAY 环境变量值，如果启动失败返回 None
    """
    global _xvfb_process, _xvfb_display
    
    # 如果已经启动，直接返回
    if _xvfb_process is not None and _xvfb_process.poll() is None:
        return _xvfb_display
    
    # 检查 Xvfb 是否已安装
    try:
        subprocess.run(['which', 'Xvfb'], check=True, capture_output=True)
    except subprocess.CalledProcessError:
        print("警告: Xvfb 未安装，无法启动虚拟显示服务器")
        return None
    
    display = f":{display_num}"
    
    try:
        # 启动 Xvfb
        _xvfb_process = subprocess.Popen(
            [
                'Xvfb',
                display,
                '-screen', str(screen), f'{width}x{height}x{depth}',
                '-ac',  # 禁用访问控制
                '-nolisten', 'tcp',  # 不监听 TCP 连接
                '+extension', 'RANDR',  # 启用 RANDR 扩展
            ],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
        
        # 等待一下确保 Xvfb 启动成功
        import time
        time.sleep(0.5)
        
        # 检查进程是否还在运行
        if _xvfb_process.poll() is None:
            _xvfb_display = display
            # 注册退出时清理函数
            atexit.register(stop_xvfb)
            signal.signal(signal.SIGTERM, lambda s, f: stop_xvfb())
            signal.signal(signal.SIGINT, lambda s, f: stop_xvfb())
            print(f"✅ Xvfb 虚拟显示服务器已启动: DISPLAY={display}")
            return display
        else:
            print("❌ Xvfb 启动失败")
            _xvfb_process = None
            return None
            
    except Exception as e:
        print(f"❌ 启动 Xvfb 时出错: {e}")
        _xvfb_process = None
        return None


def stop_xvfb():
    """停止 Xvfb 虚拟显示服务器"""
    global _xvfb_process, _xvfb_display
    
    if _xvfb_process is not None:
        try:
            _xvfb_process.terminate()
            _xvfb_process.wait(timeout=5)
            print("✅ Xvfb 虚拟显示服务器已停止")
        except subprocess.TimeoutExpired:
            _xvfb_process.kill()
            print("⚠️ 强制终止 Xvfb 进程")
        except Exception as e:
            print(f"⚠️ 停止 Xvfb 时出错: {e}")
        finally:
            _xvfb_process = None
            _xvfb_display = None


def ensure_display(headless: bool) -> bool:
    """
    确保有可用的显示环境
    
    Args:
        headless: 是否为 headless 模式
    
    Returns:
        如果成功设置显示环境返回 True，否则返回 False
    """
    # 如果是 headless 模式，不需要显示
    if headless:
        return True
    
    # 如果已经有 DISPLAY 环境变量，直接返回
    if os.environ.get('DISPLAY'):
        return True
    
    # 启动 Xvfb 并设置 DISPLAY
    display = start_xvfb()
    if display:
        os.environ['DISPLAY'] = display
        return True
    
    return False

